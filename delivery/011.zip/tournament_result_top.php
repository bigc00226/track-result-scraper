<?php
header("Content-type: charset=UTF-8");
//header("Content-type: charset=Shift-JIS");
//header("Content-type:text/html; charset=EUC-JP");


echo "<html>\r\n";
echo "<head>\r\n";
echo "<meta name='robots' content='noindex' />\r\n";
echo "<link rel='stylesheet' href='https://rikujou.jp/css/smart.css' type='text/css' />\r\n";
echo "</head>\r\n";
echo "<body>\r\n\r\n";


echo "<br />\r\n\r\n";

echo "<table align=\"center\" bgcolor=\"#333333\">\r\n\r\n";
echo "<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#D7E7FF\">\r\n";

//////////////////////////////////////////////////////////////////
//////////////////////// ���㋣�Z���o�C�� ////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>���㋣�Z���o�C��</h2>\r\n";
echo "<table align=\"center\">\r\n";
echo "<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='tournament_result2_sc.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �����L���O�t �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='tournament_result2_ranking_sc.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "</table>\r\n";

/**************************************************
echo "<table align=\"center\">\r\n";
echo "<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<b>tournament_result</b><br />\r\n";
echo "<form target='_blank' action='tournament_result.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<b>tournament_result2</b><br />\r\n";
echo "<form target='_blank' action='tournament_result2.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<b>�g�b�v�y�[�W�@���ꗗ</b><br />\r\n";
echo "<form target='_blank' action='top_tournament_list.php' method='post'>\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<b>tournament_result2�y�\�[�X�R�[�h�z</b><br />\r\n";
echo "<form target='_blank' action='tournament_result2_sc.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "</table>\r\n";
**************************************************/
//////////////////////////////////////////////////////////////////
//////////////////////// ���㋣�Z���o�C�� ////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#F7F2E0\">\r\n";

//////////////////////////////////////////////////////////////////
///////////////////////// AthleteRanking /////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>AthleteRanking�i<a target='_blank' href='http://games.athleteranking.com'>PC</a>�E<a target='_blank' href='http://games.athleteranking.com/i/'>���o�C��</a>�j</h2>\r\n";
echo "<table align=\"center\">\r\n<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<form target='_blank' action='athleteranking_pc.php' method='post'>\r\n";
echo "<input type='text' size='10' name='id' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";

echo "<tr>\r\n";
echo "<td align=\"center\" style=\"padding:0px 20px;\">\r\n";
echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='athleteranking_pc_x-day.php' method='post'>\r\n";
echo "<input type='text' size='10' name='tid' style='font-size:x-large;' placeholder=' ID' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "</table>\r\n";
//////////////////////////////////////////////////////////////////
///////////////////////// AthleteRanking /////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#E0E0F8\">\r\n";

//////////////////////////////////////////////////////////////////
/////////////////// �C���t�H���[�V�����Z���^�[ ///////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>�C���t�H���[�V�����Z���^�[</h2>\r\n";
echo "<form target='_blank' action='ic.php' method='post'>\r\n";
echo "<span  style=\"color:#800000;font-size:x-large;font-weight:bold;\">���� </span>\r\n";
echo "<input type='text' size='36' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<form target='_blank' action='ic_bangumi.php' method='post'>\r\n";
echo "<span  style=\"color:#008000;font-size:x-large;font-weight:bold;\">�ԑg </span>\r\n";
echo "<input type='text' size='36' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='ic_x-day.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
/////////////////// �C���t�H���[�V�����Z���^�[ ///////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#FFFFFF\">\r\n";

//////////////////////////////////////////////////////////////////
/////////////////////////////// 123 //////////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>123<br /></h2>\r\n";
echo "<form target='_blank' action='123_1.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='123_x-day.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
/////////////////////////////// 123 //////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#E3CEF6\">\r\n";

//////////////////////////////////////////////////////////////////
////////////////////////////// 1234 //////////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>�������̘A�i1234�j</h2>\r\n";
echo "<form target='_blank' action='1234.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='1234_x-day.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
////////////////////////////// 1234 //////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#81BEF7\">\r\n";

//////////////////////////////////////////////////////////////////
////////////////////////////// NISHI /////////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>NISHI</h2>\r\n";
echo "<form target='_blank' action='nishi.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='nishi_x-day.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
////////////////////////////// NISHI /////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#F6E3CE\">\r\n";

//////////////////////////////////////////////////////////////////
////////////////////////////// PDF ///////////////////////////////
//////////////////////////////////////////////////////////////////
// PDF ���u���E�U�̒��œǂݎ��܂��i�T�[�o�ɂ͑��M���܂���j
//   �y���ʁz        �� pdf_result.php�i1.php �Ɠ����ꗗ�\�j
//   �y�X�^�[�g���X�g�z�� pdf_startlist.php�iinfo-ch �p�� HTML�j
//   �y�^�C���e�[�u���z�� pdf_timetable.php�iHTML �̕\�j
echo "<h2 style='font-size:x-large;'>PDF�i���ʁE�X�^�[�g���X�g�E�^�C���e�[�u���j</h2>\r\n";
echo "<div style='font-size:18px;font-weight:bold;'>�y���ʁz</div>\r\n";
echo "<form onsubmit=\"return pdfToolGo(this, 'pdf_result.php', 'result');\">\r\n";
echo "<input type='file' name='pdf' accept='application/pdf,.pdf' style='font-size:large;' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�y�X�^�[�g���X�g�@info-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form onsubmit=\"return pdfToolGo(this, 'pdf_startlist.php', 'startlist');\">\r\n";
echo "<input type='file' name='pdf' accept='application/pdf,.pdf' style='font-size:large;' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�y�^�C���e�[�u���z</div>\r\n";
echo "<form onsubmit=\"return pdfToolGo(this, 'pdf_timetable.php', 'timetable');\">\r\n";
echo "<input type='file' name='pdf' accept='application/pdf,.pdf' style='font-size:large;' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

// �I�� PDF ���A�V�����^�u�̉�ʂɒ��ړn��
echo '<script>' . "\r\n";
echo 'function pdfToolGo(form, page, mode) {' . "\r\n";
echo '    var f = form.pdf.files && form.pdf.files[0];' . "\r\n";
echo '    if (!f) { alert("PDF�t�@�C����I�����Ă�������"); return false; }' . "\r\n";
echo '    window.__pdfToolFile = f;' . "\r\n";
echo '    window.__pdfToolMode = mode;' . "\r\n";
echo '    window.open(page, "_blank");' . "\r\n";
echo '    return false;' . "\r\n";
echo '}' . "\r\n";
echo '</script>' . "\r\n";
//////////////////////////////////////////////////////////////////
////////////////////////////// PDF ///////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#E6E6E6\">\r\n";

//////////////////////////////////////////////////////////////////
/////////////////////////// �����E�{�� ///////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>���������i<a target='_blank' href='http://www.fukuriku.com'>PC</a>�E<a target='_blank' href='http://frk.jpn.org/mobile/'>���o�C��</a>�j�E�{�藤���i<a target='_blank' href='http://www.miyariku.org'>PC</a>�E<a target='_blank' href='http://www.miyariku.org/keitai/'>���o�C��</a>�j</h2>\r\n";
echo "<form target='_blank' action='fm.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='fm_x-day.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
/////////////////////////// �����E�{�� ///////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#E8A399\">\r\n";

//////////////////////////////////////////////////////////////////
//////////////////////////// �É����� ////////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>�É������i<a target='_blank' href='http://shizuoka-jaaf.com/srksoku.html'>PC</a>�j</h2>\r\n";
echo "<form target='_blank' action='shizuoka.php' method='get'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
/*
echo "<form target='_blank' action='shizuoka_sokuhou.php' method='post'>\r\n";
echo "<span  style=\"color:#DF0101;font-size:x-large;font-weight:bold;\">���� </span><input type='text' size='36' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
*/

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='shizuoka_x-day.php' method='get'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
//////////////////////////// �É����� ////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;color:#F2F2F2;\" bgcolor=\"#B40404\">\r\n";

//////////////////////////////////////////////////////////////////
////////////////////////// ���{���A JAAF /////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>���{���A JAAF�i<a target='_blank' style='color:#F2F2F2;' href='https://www.jaaf.or.jp'>PC</a>�j</h2>\r\n";
echo "<form target='_blank' action='' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL�����������쐬����' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";

echo "<div style='font-size:18px;font-weight:bold;'>�yinfo-ch�p �\�[�X�R�[�h�z</div>\r\n";
echo "<form target='_blank' action='' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL�����������쐬����' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
////////////////////////// ���{���A JAAF /////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;color:#F2F2F2;\" bgcolor=\"#FA5858\">\r\n";

//////////////////////////////////////////////////////////////////
////////////////////////// ���E���A IAAF /////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>���E���A IAAF�i<a target='_blank' style='color:#585858;' href='https://www.iaaf.org'>PC</a>�j</h2>\r\n";
echo "<h2 style='font-size:x-large;'>���E����i<a target='_blank' style='color:#585858;' href='https://www.iaaf.org/competitions/iaaf-world-championships'>PC</a>�j�E�_�C�������h���[�O�i<a target='_blank' style='color:#585858;' href='https://www.iaaf.org/competitions/iaaf-diamond-league'>PC</a>�j</h2>\r\n";
echo "<form target='_blank' action='iaaf.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
////////////////////////// ���E���A IAAF /////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr name=\"rikuranall\" id=\"rikuranall\"><td name=\"rikuranevent\" id=\"rikuranevent\" align=\"center\" style=\"padding:10px 20px;color:#B40404;\" bgcolor=\"#F2F2F2\">\r\n";

//////////////////////////////////////////////////////////////////
///////////////////////// ���㋣�ZRANKING ////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>���㋣�ZRANKING�i<a target='_blank' href='https://rikumaga.com/'>PC</a>�j</h2>\r\n";
echo "<table align=\"center\"><tr>\r\n\r\n";
echo "<td align=\"center\" valign=\"top\" style=\"padding:0px 10px;\">\r\n";
echo "<div style=\"font-size:x-large;color:#2E2E2E;font-weight:bold;\">�S��ڈꊇ<br />100�ʂ܂Łi&rr=100�j</div>";
echo "<form enctype='multipart/form-data'  action='#rikuranall' method='POST'>";
echo "<input type='hidden' name='seikouall' value='100'>";
echo "<input type='file' name='upload' style='font-size:18px;padding:10px;'>";
echo "<br />";
echo "<input type='submit' style='font-size:18px;padding:10px;' value='  �t�@�C�����M  ' />";
echo "</form>";
// �t�@�C���̕ۑ���
$uploadfile = 'rikuranranking-data-all.php';
// �A�b�v���[�h���ꂽ�t�@�C���ɁA�p�X�ƃt�@�C������ݒ肵�ĕۑ�
move_uploaded_file($_FILES['upload']['tmp_name'], $uploadfile);
 // �������b�Z�[�W��\��
if ($_POST['seikouall']){
echo "<form target='_blank' action='rikuranranking-all.php' method='post'>\r\n";
echo "<input type='hidden' name='url' value='http://nextentertainmen.sakura.ne.jp/test/rikuranranking-data-all.php'>";
echo "<span style='font-size:x-large;color:#B40404;'>�@<b>��</b>�@�A�b�v���[�h�����I�@<b>��</b>�@</span><br />";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
}else{
echo "";
}

echo "<td align=\"center\" valign=\"top\" style=\"padding:0px 10px;\">\r\n";
echo "<div style=\"font-size:x-large;color:#084B8A;font-weight:bold;\">�e��ږ�<br />1000�ʂ܂�</div>";
echo "<form enctype='multipart/form-data' action='#rikuranevent' method='POST'>";
echo "<input type='hidden' name='seikouevent' value='100'>";
echo "<input type='file' name='upload2' style='font-size:18px;padding:10px;'>";
echo "<br />";
echo "<input type='submit' style='font-size:18px;padding:10px;' value='  �t�@�C�����M  ' />";
echo "</form>";
// �t�@�C���̕ۑ���
$uploadfile2 = 'rikuranranking-data-event.php';
// �A�b�v���[�h���ꂽ�t�@�C���ɁA�p�X�ƃt�@�C������ݒ肵�ĕۑ�
move_uploaded_file($_FILES['upload2']['tmp_name'], $uploadfile2);
 // �������b�Z�[�W��\��
if ($_POST['seikouevent']){
echo "<form target='_blank' action='rikuranranking-event.php' method='post'>\r\n";
echo "<input type='hidden' name='url' value='http://nextentertainmen.sakura.ne.jp/test/rikuranranking-data-event.php'>";
echo "<span style='font-size:x-large;color:#B40404;'>�@<b>��</b>�@�A�b�v���[�h�����I�@<b>��</b>�@</span><br />";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
}else{
echo "";
}
echo "</td>\r\n";
echo "</tr></table>\r\n";
//////////////////////////////////////////////////////////////////
///////////////////////// ���㋣�ZRANKING ////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n<tr><td align=\"center\" style=\"padding:10px 20px;\" bgcolor=\"#F7F6EB\">\r\n";

//////////////////////////////////////////////////////////////////
///////////////////////////// �j�[�g /////////////////////////////
//////////////////////////////////////////////////////////////////
echo "<h2 style='font-size:x-large;'>�j�[�g�i<a target='_blank' href='https://blog.neet-shikakugets.com'>PC</a>�j<img src='img/ni-to.jpg'  width='' height='40' style='vertical-align:middle;' /></h2>\r\n";
echo "<form target='_blank' action='ni-to.php' method='post'>\r\n";
echo "<input type='text' size='40' name='url' style='font-size:x-large;' placeholder=' URL' />\r\n";
echo "<input type='submit' style='font-size:x-large;' value='  GO!!  ' />\r\n";
echo "</form>\r\n";
//////////////////////////////////////////////////////////////////
///////////////////////////// �j�[�g /////////////////////////////
//////////////////////////////////////////////////////////////////

echo "</td></tr>\r\n";
echo "\r\n</table>\r\n";

echo "<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />\r\n\r\n";

echo "\r\n\r\n\r\n\r\n</body>\r\n";
echo "</html>";

?>